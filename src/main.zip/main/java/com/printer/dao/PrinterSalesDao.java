package com.printer.dao;

public class PrinterSalesDao {
}
