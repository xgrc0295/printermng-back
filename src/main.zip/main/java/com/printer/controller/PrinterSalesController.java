package com.printer.controller;

public class PrinterSalesController {
}
