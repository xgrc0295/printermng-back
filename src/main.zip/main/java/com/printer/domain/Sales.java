package com.printer.domain;

public class Sales {
}
