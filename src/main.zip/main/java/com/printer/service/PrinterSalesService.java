package com.printer.service;

public class PrinterSalesService {
}
