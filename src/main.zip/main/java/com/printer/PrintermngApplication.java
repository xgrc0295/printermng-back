package com.printer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrintermngApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrintermngApplication.class, args);
	}

}
